# Optimization Mini-Project Starter (4 Topics)

This repository is a **starter template** for the course mini-project. Student teams (2–4) pick **one** topic and extend the starter code.

## What you get here
- A clean repo skeleton (results/, figures/, src/)
- Reproducible data generators for each topic
- Minimal working runners that produce **logs** and **plots**
- Baseline hooks using **CVXPY** and/or **torch.optim** (optional but encouraged)

## What you must deliver (students)
- `report.md` in Markdown, **single column**, **≤ 5 pages**
- Code in this repo (Python scripts and/or notebooks)
- A `README.md` section stating:
  - how to install
  - how to reproduce the main results (one command or one notebook)
  - seeds used

## Quick start
### 1) Create an environment
Option A (recommended):
```bash
conda env create -f environment.yml
conda activate opt-mini
```

Option B:
```bash
pip install -r requirements.txt
```

### 2) Run a demo for a topic
Topic 1 (Group LASSO, ISTA/FISTA demo):
```bash
python scripts/run_topic1_demo.py
```

Topic 4 (Bandits demo):
```bash
python scripts/run_topic4_demo.py
```

Outputs:
- logs in `results/`
- plots in `figures/`

## Repository layout
- `src/common/`: utilities (seeding, logging, plotting)
- `src/topic1_group_lasso/`: convex + nonsmooth (group lasso)
- `src/topic2_matrix_completion/`: non-convex (low-rank factorization)
- `src/topic3_oco_logreg/`: online convex optimization (regret)
- `src/topic4_bandits/`: bandits (stochastic + adversarial)
- `scripts/`: runnable entry points

## Notes
- You are **encouraged** to use `torch.optim` and `cvxpy` as **baselines/benchmarks**.
- For your own methods, implement the **update rules** (do not rely solely on built-in optimizers).
