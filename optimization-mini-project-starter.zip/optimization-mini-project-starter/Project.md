# Mini-Project: Pick 1 of 4 Topics (Implementation-Focused)

See the course handout for full requirements. This template provides runnable demos and baseline hooks.

General metrics to report (pick at least 3, as appropriate):
- solution quality: objective value/gap, feasibility, recovery error
- speed: time, iterations, gradient evaluations
- convergence: curves vs iterations/time, stationarity/KKT surrogate
- online/bandit: regret and regret/T
